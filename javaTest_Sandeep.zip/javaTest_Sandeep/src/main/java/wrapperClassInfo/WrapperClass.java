package wrapperClassInfo;

import java.util.Scanner;

public class WrapperClass {
	
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		//1st Conversion
		Integer n1 = sc.nextInt();
		
		byte n2 = n1.byteValue();
		System.out.println("Converted value of " + n1 + " in bytes is: " + n2);
		
		float n3 = n1.floatValue();
		System.out.println("Converted value of " + n1 + " in float is: " + n3);
		
		double n4 = n1.doubleValue();
		System.out.println("Converted value of " + n1 + " in double is: " + n4);
		
		Long n5 = n1.longValue();
		System.out.println("Converted value of " + n1 + " in long is: " + n5);
		
		
		//2nd Conversion
		String str = n1.toString();
		System.out.println("Converted value of " + n1 + " in String format is: " + str);
		
		
		//3rd Conversion
		String str1 = sc.next();
		int i = Integer.parseInt(str1.trim()); 		
		System.out.println("Converted value of " + str1 + " in integer is: " + i);
		
		
		//4th Conversion
		char ch1 = 'r';
		String str2 = String .valueOf(ch1);
		System.out.println("Converted value of " + ch1 + " in String format is: " + str2);
		
		
		//5th Conversion
		String str3 = sc.next();
		char c = str3.charAt(0);
		System.out.println("First character value present in " + str3 + " is: " + c);
		
		System.out.println();
		
		//6th Conversion
		String str4 = "Robert";
		
		StringBuilder sbOb = new StringBuilder(str4);
		sbOb.append(" Lewandowski");
		System.out.println(sbOb);
		
		sbOb.insert(7, "JR ");
		System.out.println(sbOb);
		
		sbOb.substring(0, 6);
		System.out.println(sbOb);
		
		sbOb.replace(8, 10, " NINE ");
		System.out.println(sbOb);
		
		sbOb.delete(0, 3);
		System.out.println(sbOb);
		
		char ch = sbOb.charAt(10);
		System.out.println(ch);
		
		sc.close();
	}

}
