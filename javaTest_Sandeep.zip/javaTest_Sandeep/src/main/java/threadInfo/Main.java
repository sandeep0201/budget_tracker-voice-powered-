package threadInfo;

public class Main {

}
