package threadInfo;

public class CircleInfo extends ShapeInfo{

	public CircleInfo(int side) {
		super(side);
	}
	
	@Override
	public double areaOfShape()
	{
		System.out.println("Calculating area: ");
		return 3.14 * this.getSide1() * this.getSide1();
	}
	
	@Override
	public double perimeterOfShape()
	{
		System.out.println("Calculating perimeter: ");
		return 2 * 3.14 * this.getSide1();
	}
}
